function setup() 
{
  
  createCanvas(800, 800);
  frameRate(30);

  colorMode(HSB);
//colorRBS(RBS);
}


function draw()
{
  background(0, 200, 15);

  let x = width * 0.5 + 100 * sin(frameCount * 0.01);
  let y = height * 0.5;
  var x1= width*Math.sin(frameCount*0.01)

  rect(x, y, 40, 40);
  rect(x + 15, y + 20, 9, 20);
  rect(x, 420, 10, 10);
  rect(x + 30, 420, 10, 10);
  rect(x + 25, y + -20, 10, 20);
  rect(x, 433, 14, 6);
  rect(x + 25, 433, 14, 6);
  
  triangle(x, y, x + 40,y, x + 20, y - 20);
  

}



















